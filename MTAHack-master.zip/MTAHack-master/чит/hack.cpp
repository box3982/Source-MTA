#include "main.hpp"

/*

������� � �� ������ ����� ��� (��� �������):

https://gtamods.com/wiki/Memory_Addresses_(SA)
http://gtamodding.ru/wiki/%D0%90%D0%B4%D1%80%D0%B5%D1%81%D0%B0_%D0%9F%D0%B0%D0%BC%D1%8F%D1%82%D0%B8_(SA)

*/

void hack() {

	while (true) {

		if (Utils->Check()) {

			if (GetAsyncKeyState(VK_PRIOR) & 1)
			{
				Global->g_airSpeed += 0.1f;
				Call<0x69F1E0>(Utils->ToString < float >(Global->g_airSpeed).data(), 500, 12, true);
			}

			if (GetAsyncKeyState(VK_NEXT) & 1) {
				if (Global->g_airSpeed > 0.2f) {
					Global->g_airSpeed -= 0.1f;
				}
				Call<0x69F1E0>(Utils->ToString < float >(Global->g_airSpeed).data(), 500, 12, true);
			}

			if (*(DWORD*)(0xBA18FC) > 0) { // ��������

				//SpeedHack
				if (GetAsyncKeyState(VK_LSHIFT)) {

					DWORD CARSELF = *(DWORD*)0xBA18FC;

					*(float*)(CARSELF + 0x44) *= Global->g_airSpeed / 10 + 1.01f;
					*(float*)(CARSELF + 0x48) *= Global->g_airSpeed / 10 + 1.01f;
					*(float*)(CARSELF + 0x4C) *= Global->g_airSpeed / 10 + 1.01f;

					Sleep(132);
				}

			}

		}

		Sleep(10);

	}

}