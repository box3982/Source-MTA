#pragma once

#include <Windows.h>

#include "global.hpp"
#include "utils.hpp"
#include "CallFuncs.hpp"

#define MsgBox(a, b) MessageBox(0, a, b, 0)

extern global* Global;
extern utils* Utils;

void hack();
