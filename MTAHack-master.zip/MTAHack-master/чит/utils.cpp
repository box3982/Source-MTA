#include "utils.hpp"
#include "global.hpp"
#include "main.hpp"

void utils::NopBoolFunc(LPVOID address, bool ret) {
	DWORD NewProtection;
	::VirtualProtect((LPVOID)address, 3, PAGE_EXECUTE_READWRITE, &NewProtection);

	BYTE* pFun = (BYTE*)address;
	pFun[0] = 0xB0;

	if (ret) {
		pFun[1] = 0x01;
	}
	else {
		pFun[1] = 0x00;
	}

	pFun[2] = 0xC3;

	::VirtualProtect((LPVOID)address, 3, NewProtection, &NewProtection);
}

void utils::WriteMemory(void* address, void* bytes, int byteSize)
{
	DWORD NewProtection;
	::VirtualProtect(address, byteSize, PAGE_EXECUTE_READWRITE, &NewProtection);
	memcpy(address, bytes, byteSize);
	::VirtualProtect(address, byteSize, NewProtection, &NewProtection);
}

void utils::nop_(PVOID address, int bytes) {
	DWORD NewProtection;
	::VirtualProtect(address, bytes, PAGE_EXECUTE_READWRITE, &NewProtection);
	memset(address, 0x90, bytes);
	::VirtualProtect(address, bytes, NewProtection, &NewProtection);
}

CVector utils::GetPos(DWORD CPed) {
	CVector pos; DWORD Matrix =
		*(DWORD*)(CPed + 0x14);

	pos.fX = *(float*)(Matrix + 0x30);
	pos.fY = *(float*)(Matrix + 0x34);
	pos.fZ = *(float*)(Matrix + 0x38);

	return pos;
}

CVector utils::GetPedPos(DWORD CPed) {
	return GetPos(CPed);
}

CVector utils::GetMyPos() {
	return GetPos(*(DWORD*)0xB6F5F0);
}

bool utils::Check() {
	if (GetModuleHandleA("client.dll") == NULL)
		return false;

	HWND test = GetForegroundWindow();
	if (test != Global->m_pGameWindow)
		return false;

	if (*(DWORD*)0xB6F5F0 == 0)
		return false;

	DWORD PEDSELF = *(DWORD*)0xB6F5F0;

	if (*(float*)(PEDSELF + 0x540) == 0)
		return false;

	CVector pos = GetMyPos();

	if (pos.fX > -5 && pos.fX < 5 && pos.fY > -5 && pos.fY < 5 && pos.fZ > -5 && pos.fZ < 5)
		return false;

	return true;
}