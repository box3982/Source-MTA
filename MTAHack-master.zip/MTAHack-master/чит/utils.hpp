#pragma once
#include <Windows.h>
#include <sstream>

#include "CVector.hpp"

class utils {
public:
	void NopBoolFunc(LPVOID address, bool ret);
	void WriteMemory(void* address, void* bytes, int byteSize);
	void nop_(PVOID address, int bytes);
	bool Check();
	CVector GetMyPos(); 
	CVector GetPedPos(DWORD CPed);
	
private:
	CVector GetPos(DWORD CPed);

public:
	template <typename Type>
	std::string ToString(Type a) {
		std::stringstream ss;
		ss << a;
		std::string str = ss.str();
		return str;
	}
};
