#pragma once

class global
{
public:
	float g_airSpeed = 5.f;
	HWND m_pGameWindow = nullptr;
};	